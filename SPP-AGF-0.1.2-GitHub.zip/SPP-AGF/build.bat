@echo off
setlocal
cd /d "%~dp0"

if not exist build mkdir build

where sppc >nul 2>nul
if errorlevel 1 (
  echo [ERROR] sppc was not found in PATH.
  echo Install the original compiler: https://github.com/f35clt2/sppc
  exit /b 1
)

if "%CC%"=="" set "CC=gcc"
if "%SDL2_INCLUDE%"=="" set "SDL2_INCLUDE=C:\msys64\ucrt64\include\SDL2"
if "%SDL2_LIB%"=="" set "SDL2_LIB=C:\msys64\ucrt64\lib"
if "%SDL2_BIN%"=="" set "SDL2_BIN=C:\msys64\ucrt64\bin"

where "%CC%" >nul 2>nul
if errorlevel 1 (
  echo [ERROR] C compiler not found: %CC%
  exit /b 1
)

if not exist "%SDL2_INCLUDE%\SDL.h" (
  echo [ERROR] SDL.h not found in "%SDL2_INCLUDE%"
  echo Set SDL2_INCLUDE to the directory containing SDL.h.
  exit /b 1
)

if not exist "%SDL2_LIB%\libSDL2.a" if not exist "%SDL2_LIB%\libSDL2.dll.a" (
  echo [ERROR] SDL2 import library not found in "%SDL2_LIB%"
  echo Set SDL2_LIB to the SDL2 library directory.
  exit /b 1
)

echo [1/3] Translating S++ source to C...
sppc examples\hello.spp --allow-foreign --emit-c build\hello.c
if errorlevel 1 exit /b 1

echo [2/3] Compiling generated C and AGF backend...
"%CC%" -std=c99 -O2 -Iinclude -I"%SDL2_INCLUDE%" build\hello.c src\agf.c -L"%SDL2_LIB%" -lmingw32 -lSDL2main -lSDL2 -o build\hello.exe
if errorlevel 1 exit /b 1

echo [3/3] Copying SDL2 runtime if available...
if exist "%SDL2_BIN%\SDL2.dll" copy /y "%SDL2_BIN%\SDL2.dll" build\ >nul

echo.
echo Build successful: build\hello.exe
echo Run it with: build\hello.exe
exit /b 0
