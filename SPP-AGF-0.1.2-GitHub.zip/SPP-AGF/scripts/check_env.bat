@echo off
setlocal
echo === SPP AGF environment check ===
where sppc >nul 2>nul && (echo [OK] sppc found) || (echo [MISSING] sppc)
where gcc >nul 2>nul && (echo [OK] gcc found) || (echo [MISSING] gcc)
if "%SDL2_INCLUDE%"=="" set "SDL2_INCLUDE=C:\msys64\ucrt64\include\SDL2"
if "%SDL2_LIB%"=="" set "SDL2_LIB=C:\msys64\ucrt64\lib"
if exist "%SDL2_INCLUDE%\SDL.h" (echo [OK] SDL.h found) else (echo [MISSING] SDL.h: %SDL2_INCLUDE%)
if exist "%SDL2_LIB%\libSDL2.a" (echo [OK] SDL2 library found) else if exist "%SDL2_LIB%\libSDL2.dll.a" (echo [OK] SDL2 import library found) else (echo [MISSING] SDL2 import library: %SDL2_LIB%)
echo.
echo Note: finding these tools does not guarantee that the upstream sppc build is compatible with this shell.
endlocal
