# Сборка SPP AGF

## 1. Установите оригинальный S++

Исходный проект: https://github.com/f35clt2/sppc

Upstream README описывает `sppc` как source-to-source compiler, который преобразует S++ в C, после чего использует GCC. Там же указаны GCC, libc и POSIX environment. Следуйте актуальной инструкции upstream для вашей системы.

Проверьте:

```bat
sppc --version
gcc --version
```

## 2. Установите SDL2 development package

Для MinGW-w64 нужны:
- `SDL.h`;
- SDL2 import library (`libSDL2.a` или `libSDL2.dll.a`);
- `SDL2.dll` для запуска программы.

Стандартные пути MSYS2 UCRT64:
- `C:\msys64\ucrt64\include\SDL2`;
- `C:\msys64\ucrt64\lib`;
- `C:\msys64\ucrt64\bin`.

## 3. Соберите пример

Запустите `build.bat` из корня проекта. При нестандартных путях задайте `SDL2_INCLUDE`, `SDL2_LIB`, `SDL2_BIN` и `CC`.

Скрипт выполняет два отдельных этапа:
1. `sppc` генерирует C-файл из `examples/hello.spp`;
2. GCC компилирует сгенерированный C вместе с `src/agf.c` и SDL2.

Если ваша сборка upstream `sppc` не поддерживает запуск в текущей Windows shell, используйте ту POSIX-среду, которую требует upstream. Это ограничение самого исходного компилятора, а не AGF.
