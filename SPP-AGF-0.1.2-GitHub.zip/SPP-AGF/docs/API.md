# SPP AGF API

Include `agf.h` from the C code passed to `stdc:RunC`.

| Function | Description |
|---|---|
| `int agf_init(const char *title, int width, int height)` | Creates the window and renderer. Returns 1 on success. |
| `int agf_poll_events(void)` | Processes SDL events; returns 0 after close. |
| `void agf_clear(int r, int g, int b, int a)` | Clears the frame. |
| `void agf_set_color(int r, int g, int b, int a)` | Sets RGBA draw color. |
| `void agf_fill_rect(int x, int y, int width, int height)` | Draws a filled rectangle. |
| `void agf_draw_rect(int x, int y, int width, int height)` | Draws an outline rectangle. |
| `void agf_draw_text(const char *text, int x, int y, int scale)` | Draws uppercase ASCII bitmap text. |
| `void agf_present(void)` | Presents the frame. |
| `void agf_shutdown(void)` | Destroys resources and quits SDL. |

Coordinates are measured in pixels from the top-left corner. Color components are converted to 8-bit values. Text currently uses a built-in 5x7 font and supports A-Z, 0-9, dash, dot and colon.
