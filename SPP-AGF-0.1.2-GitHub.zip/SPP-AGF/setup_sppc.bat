@echo off
echo SPP AGF uses the original S++ compiler.
echo.
echo Official source: https://github.com/f35clt2/sppc
echo.
echo The upstream compiler currently documents GCC, libc and a POSIX environment.
echo This setup helper intentionally does not download or replace compiler sources.
echo Install/build sppc using the upstream instructions, then make sure "sppc" is in PATH.
echo.
echo Verify with:
echo   sppc --version
echo.
pause
