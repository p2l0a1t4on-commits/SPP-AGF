#ifndef SPP_AGF_H
#define SPP_AGF_H

#ifdef __cplusplus
extern "C" {
#endif

/* Returns 1 on success, 0 on failure. */
int agf_init(const char *title, int width, int height);

/* Pumps SDL events. Returns 1 while the window should remain open. */
int agf_poll_events(void);

/* Clears the current render target with RGBA color. */
void agf_clear(int r, int g, int b, int a);

/* Sets the drawing color used by subsequent primitive calls. */
void agf_set_color(int r, int g, int b, int a);

/* Draws a filled rectangle. */
void agf_fill_rect(int x, int y, int width, int height);

/* Draws a rectangle outline. */
void agf_draw_rect(int x, int y, int width, int height);

/* Draws uppercase ASCII bitmap text. scale must be >= 1. */
void agf_draw_text(const char *text, int x, int y, int scale);

/* Presents the back buffer. */
void agf_present(void);

/* Releases SDL resources. Safe to call more than once. */
void agf_shutdown(void);

#ifdef __cplusplus
}
#endif

#endif
