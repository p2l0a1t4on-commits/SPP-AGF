#include "agf.h"
#include <SDL.h>
#include <stddef.h>

static SDL_Window *g_window = NULL;
static SDL_Renderer *g_renderer = NULL;
static int g_running = 0;
static SDL_Color g_color = {255, 255, 255, 255};

static void set_draw_color(SDL_Color c) {
    if (g_renderer) SDL_SetRenderDrawColor(g_renderer, c.r, c.g, c.b, c.a);
}

/* 5x7 glyphs. Rows use the low five bits, left-to-right. */
static const unsigned char *glyph_for(char ch) {
    static const unsigned char blank[7] = {0,0,0,0,0,0,0};
    static const unsigned char glyphs[36][7] = {
        {14,17,19,21,25,17,14}, /* 0 */
        {4,12,4,4,4,4,14},      /* 1 */
        {14,17,1,2,4,8,31},     /* 2 */
        {30,1,1,14,1,1,30},     /* 3 */
        {2,6,10,18,31,2,2},     /* 4 */
        {31,16,16,30,1,1,30},   /* 5 */
        {14,16,16,30,17,17,14}, /* 6 */
        {31,1,2,4,8,8,8},       /* 7 */
        {14,17,17,14,17,17,14}, /* 8 */
        {14,17,17,15,1,1,14},   /* 9 */
        {14,17,17,31,17,17,17}, /* A */
        {30,17,17,30,17,17,30}, /* B */
        {14,17,16,16,16,17,14}, /* C */
        {30,17,17,17,17,17,30}, /* D */
        {31,16,16,30,16,16,31}, /* E */
        {31,16,16,30,16,16,16}, /* F */
        {14,17,16,23,17,17,15}, /* G */
        {17,17,17,31,17,17,17}, /* H */
        {14,4,4,4,4,4,14},      /* I */
        {7,2,2,2,2,18,12},      /* J */
        {17,18,20,24,20,18,17}, /* K */
        {16,16,16,16,16,16,31}, /* L */
        {17,27,21,21,17,17,17}, /* M */
        {17,25,21,19,17,17,17}, /* N */
        {14,17,17,17,17,17,14}, /* O */
        {30,17,17,30,16,16,16}, /* P */
        {14,17,17,17,21,18,13}, /* Q */
        {30,17,17,30,20,18,17}, /* R */
        {15,16,16,14,1,1,30},   /* S */
        {31,4,4,4,4,4,4},       /* T */
        {17,17,17,17,17,17,14}, /* U */
        {17,17,17,17,17,10,4},  /* V */
        {17,17,17,21,21,21,10}, /* W */
        {17,17,10,4,10,17,17},  /* X */
        {17,17,10,4,4,4,4},     /* Y */
        {31,1,2,4,8,16,31}      /* Z */
    };
    static const unsigned char dash[7] = {0,0,0,31,0,0,0};
    static const unsigned char dot[7] = {0,0,0,0,0,12,12};
    static const unsigned char colon[7] = {0,12,12,0,12,12,0};
    if (ch >= 'a' && ch <= 'z') ch = (char)(ch - 'a' + 'A');
    if (ch >= '0' && ch <= '9') return glyphs[ch - '0'];
    if (ch >= 'A' && ch <= 'Z') return glyphs[10 + ch - 'A'];
    if (ch == '-') return dash;
    if (ch == '.') return dot;
    if (ch == ':') return colon;
    return blank;
}

int agf_init(const char *title, int width, int height) {
    if (g_renderer) return 1;
    if (SDL_Init(SDL_INIT_VIDEO) != 0) return 0;
    g_window = SDL_CreateWindow(
        title ? title : "SPP AGF",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        width > 0 ? width : 800, height > 0 ? height : 500,
        SDL_WINDOW_SHOWN
    );
    if (!g_window) {
        SDL_Quit();
        return 0;
    }
    g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_ACCELERATED);
    if (!g_renderer) g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_SOFTWARE);
    if (!g_renderer) {
        SDL_DestroyWindow(g_window);
        g_window = NULL;
        SDL_Quit();
        return 0;
    }
    g_running = 1;
    return 1;
}

int agf_poll_events(void) {
    SDL_Event event;
    if (!g_running) return 0;
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) g_running = 0;
        if (event.type == SDL_WINDOWEVENT &&
            event.window.event == SDL_WINDOWEVENT_CLOSE) g_running = 0;
    }
    return g_running;
}

void agf_clear(int r, int g, int b, int a) {
    if (!g_renderer) return;
    SDL_SetRenderDrawColor(g_renderer, (Uint8)r, (Uint8)g, (Uint8)b, (Uint8)a);
    SDL_RenderClear(g_renderer);
}

void agf_set_color(int r, int g, int b, int a) {
    g_color.r = (Uint8)r; g_color.g = (Uint8)g;
    g_color.b = (Uint8)b; g_color.a = (Uint8)a;
    set_draw_color(g_color);
}

void agf_fill_rect(int x, int y, int width, int height) {
    if (!g_renderer || width <= 0 || height <= 0) return;
    SDL_Rect rect = {x, y, width, height};
    set_draw_color(g_color);
    SDL_RenderFillRect(g_renderer, &rect);
}

void agf_draw_rect(int x, int y, int width, int height) {
    if (!g_renderer || width <= 0 || height <= 0) return;
    SDL_Rect rect = {x, y, width, height};
    set_draw_color(g_color);
    SDL_RenderDrawRect(g_renderer, &rect);
}

void agf_draw_text(const char *text, int x, int y, int scale) {
    if (!g_renderer || !text) return;
    if (scale < 1) scale = 1;
    set_draw_color(g_color);
    for (size_t i = 0; text[i] != '\0'; ++i) {
        const unsigned char *glyph = glyph_for(text[i]);
        for (int row = 0; row < 7; ++row) {
            for (int col = 0; col < 5; ++col) {
                if (glyph[row] & (1u << (4 - col))) {
                    SDL_Rect pixel = {
                        x + (int)i * 6 * scale + col * scale,
                        y + row * scale,
                        scale, scale
                    };
                    SDL_RenderFillRect(g_renderer, &pixel);
                }
            }
        }
    }
}

void agf_present(void) {
    if (g_renderer) SDL_RenderPresent(g_renderer);
}

void agf_shutdown(void) {
    if (g_renderer) SDL_DestroyRenderer(g_renderer);
    if (g_window) SDL_DestroyWindow(g_window);
    g_renderer = NULL;
    g_window = NULL;
    g_running = 0;
    SDL_Quit();
}
